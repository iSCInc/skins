<?php
    $cavendishColor = 'blue'; 
    $cavendishLogoURL = false; 
    $cavendishLogoWidth = '322'; 
    $cavendishLogoHeight = '53';
    $cavendishLogoMargin = '10'; 
    $cavendishSiteWith = false; 
    $cavendishExtensionCSS = true; 
    $cavendishSidebarSearchbox =false;
	$cavendishQRCode = true;
	/* if showed on page or only on print (all, print)*/
	$cavendishQRCodeMode = 'all';
	$cavendishQRurladd = "?pk_campaign=qr-code";
?>