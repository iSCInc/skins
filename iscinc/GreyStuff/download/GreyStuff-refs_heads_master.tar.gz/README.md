mw-skin-greystuff
=================

Random grey skin for MediaWiki

IT KIND OF MOSTLY WORKS MAYBE.
