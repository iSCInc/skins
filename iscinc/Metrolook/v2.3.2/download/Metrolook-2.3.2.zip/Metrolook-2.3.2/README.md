Metrolook
=========

A skin for MediaWiki

The author of the skin is http://www.pidgi.net/wiki/Main_Page


Compatible with MediaWiki 1.24+

If you would like compatibility with mediawiki 1.23, 1.22 or 1.21 please visit 

1.23

https://github.com/paladox2015/Metrolook/tree/MediaWiki-1.23

1.22

https://github.com/paladox2015/Metrolook/tree/MediaWiki-1.22

1.21

https://github.com/paladox2015/Metrolook/tree/MediaWiki-1.21

Please be aware that there are issues in the codes if you see any could you point it out it would help. and there are things like logos already set sorry i will put a setting there.

A working demo of the skin is available at http://pidgi.net/metrolooktest/index.php/Main_Page . This is currently using MediaWiki 1.24wmf18 and version 2.3 of the master branch of the skin.


## Settings

1.24 only

To enable logo

$Logoshow = true;

Default is

$Logoshow = false;

To enable sidebar search bar

$SearchBar = false;

Default is

$SearchBar = true;


## Known Issues

* Mobile view of desktop is not shown correcly.


## Version

3.x.x requires MediaWiki 1.25.

2.x.x requires MediaWiki 1.24.

1.x.x requires MediaWiki 1.23.
