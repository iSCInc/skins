This is a skin for MediaWiki that looks similar to the Discourse's design.

Drop it in $wgScriptPath/skins/DiscourseSkin and add this line to your LocalSettings.php:

    require_once( "$IP/skins/DiscourseSkin/DiscourseSkin.php" );
