## Version 1.1

* [feature] Addition of Social Media Follow Icons using AddThis horizontal follow bar
* [feature] Turn on or off the display of standard MW footer icons
* [feature] Navbar image/icon, ability to change title shown in navbar independent of $wgSitename, and turn on/off image/icon in navbar.
* [feature] Ability to change the displayed title name independent of $wgSitename 
* [bug fix] Parent <div> for mw-content-text <div>
* [bug fix] Missing icon for Atom(RSS) Feedlink
* [bug fix] Fix Font Awesome icon alignment
* [feature] i18n json update/create shim, i18n.php file for localization deprecated in MW 1.23 and being removed in MW 1.24, and shim is backwards compatable to MW 1.17
* Added CONTRIBUTING.md file
* Update to README.md
