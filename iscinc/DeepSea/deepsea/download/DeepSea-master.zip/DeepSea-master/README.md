DeepSea
=======

DeepSea is a MediaWiki skin developed for use on Brickimedia

https://www.mediawiki.org/wiki/Skin:DeepSea
