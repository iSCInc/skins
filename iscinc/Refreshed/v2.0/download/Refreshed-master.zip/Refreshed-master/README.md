Refreshed
=========

A new clean, modern MediaWiki skin used on Brickimedia.
